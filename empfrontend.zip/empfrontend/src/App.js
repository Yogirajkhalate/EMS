import './App.css';
import ListEmployee from './component/ListEmployee';

function App() {
  return (
    <>
    <ListEmployee/>

    </>
  );
}

export default App;
