
import React, { useState } from "react";
import axios from "axios";

const ListEmployee = () => {
  const [employees, setEmployees] = useState([]);

  const fetchEmployees = () => {
    axios.get("http://localhost:9098/api/employees")
      .then((response) => {
        setEmployees(response.data);
      })
      .catch((error) => {
        console.error("Error fetching employees:", error);
      });
  };

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col items-center p-6">
      <h1 className="text-2xl font-bold mb-4">Employee List</h1>
      <button onClick={fetchEmployees} className="mb-4 px-4 py-2 bg-blue-500 text-white rounded-lg shadow">
        Load Employees
      </button>
      <div className="w-full max-w-2xl bg-white shadow-md rounded-lg p-4">
        <table className="w-full border-collapse border border-gray-300">
          <thead>
            <tr className="bg-gray-200">
              <th className="border border-gray-300 p-2">Emp ID</th>
              <th className="border border-gray-300 p-2">First Name</th>
              <th className="border border-gray-300 p-2">Last Name</th>
              <th className="border border-gray-300 p-2">Email</th>
            </tr>
          </thead>
          <tbody>
            {employees.map((employee) => (
              <tr key={employee.empId} className="text-center">
                <td className="border border-gray-300 p-2">{employee.empId}</td>
                <td className="border border-gray-300 p-2">{employee.firstName}</td>
                <td className="border border-gray-300 p-2">{employee.lastName}</td>
                <td className="border border-gray-300 p-2">{employee.email}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ListEmployee;
